package com.userFront.service;

import java.security.Principal;
import java.util.List;

import com.userFront.domain.PrimaryAccount;
import com.userFront.domain.SavingsAccount;

public interface AccountService {

	List<PrimaryAccount> createPrimaryAccount();
	List<SavingsAccount> createSavingsAccount();
	
	void deposit(String accountType, double amount, Principal principal);
	void withdraw(String accountType, double amount, Principal principal);
}
